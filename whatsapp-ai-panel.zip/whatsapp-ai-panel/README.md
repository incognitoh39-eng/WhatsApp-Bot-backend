# Panel IA para WhatsApp (Termux + Groq)

Sistema de 3 piezas:

1. **`backend/`** — servidor Node (Express + Socket.io) que sirve el panel web y hace de
   puente entre tu navegador y el bot que corre en Termux. Es el único que necesitas
   tener alojado en algún lado accesible por internet (Render, Railway, un VPS, etc).
2. **`frontend/`** — el panel web (lo sirve el mismo backend, no hay que desplegarlo aparte).
3. **`bot-termux/`** — el "worker": el script que ejecutas en tu celular con Termux. Usa
   [Baileys](https://github.com/WhiskeySockets/Baileys) para hablar con WhatsApp y se
   conecta al panel por Socket.io.

## Flujo de uso

1. Abres el panel web → escribes tu número → te da un comando para pegar en Termux.
2. Corres ese comando en Termux (dentro de la carpeta `bot-termux`). El bot se conecta
   al panel y, cuando el panel se lo pide, genera el código de 8 dígitos de WhatsApp.
3. Ingresas ese código en tu celular: **WhatsApp → Dispositivos vinculados → Vincular
   con número de teléfono**.
4. En cuanto WhatsApp confirma la vinculación, el panel te pide tu **API key de Groq**
   (gratis en [console.groq.com/keys](https://console.groq.com/keys)). Esa clave se
   manda directo a tu propio worker de Termux; el servidor del panel no la guarda en disco.
5. Se abre el listado de tus contactos con un interruptor por cada uno. Solo los
   contactos que actives recibirán respuesta automática de la IA. Los grupos nunca
   se autoresponden (por diseño, para evitar spam accidental).

## Poner el backend a correr

```bash
cd backend
npm install
npm start
# Por defecto queda en http://localhost:3000
```

Si lo vas a usar desde tu celular real (no solo en local), despliega esta carpeta en
cualquier servicio que dé un dominio público (Render, Railway, Fly.io, un VPS con Nginx,
etc). Lo único que necesitas exponer es el puerto donde corre `server.js`.

## Poner el bot a correr en Termux

```bash
pkg update && pkg upgrade -y
pkg install nodejs git -y

git clone <tu-repo-o-copia-esta-carpeta> whatsapp-ai-panel
cd whatsapp-ai-panel/bot-termux
npm install

# Este es el comando que normalmente te da el panel web ya armado:
SESSION_ID=XXXXXXXX SERVER_URL=https://tu-panel.ejemplo.com node bot.js
```

- `SESSION_ID`: lo genera el panel web cada vez que empiezas el flujo (paso 1).
- `SERVER_URL`: la URL pública donde tienes corriendo `backend/`.

La primera vez que el bot conecta a WhatsApp guarda sus credenciales en la carpeta
`sesion_whatsapp/` (igual que cualquier bot con Baileys), así que si reinicias Termux
no hace falta volver a vincular, mientras esa carpeta siga ahí.

## Notas de seguridad

- La API key de Groq viaja del navegador → backend → worker por Socket.io y se
  guarda **solo en memoria** en ambos lados. Si reinicias el backend o el worker,
  hay que volver a pegarla.
- El backend no persiste nada en disco por defecto (sesiones en memoria). Si quieres
  que sobrevivan a un reinicio del servidor, agrega tu propia capa de persistencia
  (Redis, SQLite, etc) sobre el `Map` de `sesiones` en `backend/server.js`.
- Usa esto solo con tu propio número de WhatsApp. Automatizar cuentas ajenas sin
  consentimiento puede violar los términos de uso de WhatsApp.
